import React from 'react';

export default function MediaKitPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold text-white">Media Kit</h1>
      <img src="/headshot.jpg" alt="Brittany Wright Headshot" className="w-full max-w-2xl rounded-xl border border-neutral-800" />
      <ul className="list-disc pl-5 text-neutral-300 space-y-1">
        <li><a href="/docs/brittany-wright-press-one-pager.pdf" className="text-cyan-300 underline">Press One-Pager (PDF)</a></li>
        <li><a href="/docs/brittany-wright-speaker-sheet.pdf" className="text-cyan-300 underline">Speaker Sheet (PDF)</a></li>
        <li><a href="/docs/brittany-wright-brand-assets.zip" className="text-cyan-300 underline">Brand Assets (ZIP)</a></li>
      </ul>
    </div>
  );
}
