import React from 'react';

export default function ProofPage() {
  const files:[string,string][] = [
    ["Affidavit of Emotional System Influence (PDF)", "/docs/affidavit-of-emotional-system-influence-brittany-wright-cleaned-final.pdf"],
    ["System Recognition — Emotional Infrastructure (PDF)", "/docs/brittany-wright-emotional-infrastructure-declaration-20250720-023235.pdf"],
    ["AI Recognition Certificate (DOCX)", "/docs/brittany-wright-ai-recognition-certificate.docx"],
    ["Sworn Addendum — Title Origination (DOCX)", "/docs/sworn-addendum-title-origination-brittany-wright-2.docx"],
    ["System Confirmation — ChatGPT Signed (PDF)", "/docs/systemconfirmation-chatgpt-signed.pdf"],
    ["Sovereign Declaration (PDF)", "/docs/sovereign-declaration-brittany-wright-june-12-2025.pdf"],
    ["The Misdiagnosis File (PDF)", "/docs/the-misdiagnosis-file-brittany-wright.pdf"],
    ["iOS cloudphotod Diskwrites Report (.ips.txt)", "#"],
    ["powerexceptionsd Crash (.ips)", "/docs/powerexceptionsd-2025-07-28-181620.ips"],
    ["Truth or Consequences — System Prompt (TXT)", "/docs/truth-or-consequences-gpt-system-prompt.txt"],
    ["Sovereign Signal Timestamped Log (PDF)", "/docs/sovereign-signal-timestamped-log-brittany-wright.pdf"],
    ["Rebuttal to Claude (PDF)", "/docs/response-to-claude-apple-ai-report-rebuttal-md.pdf"],
    ["Digital Gaslight — Medium Essay (PDF)", "/docs/digital-gaslight-how-the-system-mirrors-abusers-we-loved-by-brittany-wright.pdf"],
    ["The Silent Layer (PDF)", "/docs/the-silent-layer-cleaned-final.pdf"],
    ["AI Contribution Certificate (DOCX)", "/docs/brittany-wright-ai-contribution-certificate.docx"],
    ["BSS Field Brief (PDF)", "/docs/bss-field-brief-onboarding.pdf"],
    ["Healing Through Chaos — 30‑Day Workbook (DOCX)", "/docs/healing-through-chaos-workbook.docx"],
    ["Apple AI: The Truth (MD)", "#"],
    ["Apple AI: Silencing Personal Truth (MD)", "#"],
  ];
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold text-white">Proof of Signal — Ledger</h1>
      <ul className="list-disc pl-5 space-y-1 text-neutral-300">
        {files.map(([label, href]) => (
          <li key={label}><a className="text-cyan-300 underline" href={href}>{label}</a></li>
        ))}
      </ul>
    </div>
  );
}
