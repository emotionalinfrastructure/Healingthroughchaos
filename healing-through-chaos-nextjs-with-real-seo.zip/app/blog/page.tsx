import React from 'react';

export default function BlogPage() {
  const posts:[string,string][] = [
    ["Digital Gaslight — How the System Mirrors Abusers We Loved", "/docs/digital-gaslight-how-the-system-mirrors-abusers-we-loved-by-brittany-wright.pdf"],
    ["The Silent Layer — Hidden AI Activity on Your Device", "/docs/the-silent-layer-cleaned-final.pdf"],
    ["Apple AI: The Truth (MD)", "#"],
    ["Apple AI: Silencing Personal Truth (MD)", "#"],
  ];
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold text-white">Field Notes & Essays</h1>
      <ul className="list-disc pl-5 space-y-1 text-neutral-300">
        {posts.map(([t, href]) => (<li key={t}><a className="text-cyan-300 underline" href={href}>{t}</a></li>))}
      </ul>
    </div>
  );
}
