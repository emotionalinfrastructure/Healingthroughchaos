import './globals.css';
import type { Metadata } from 'next';
import SiteChrome from '@/components/SiteChrome';

const siteName = 'Healing Through Chaos';
const siteDescription = 'Trauma-Informed Systems for Real-World Recovery — tools, proofs, and kits designed by lived experience.';
const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://healing-through-chaos.example.com';
const ogImage = `${siteUrl}/headshot.jpg`;

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: siteName,
    template: `%s • ${siteName}`
  },
  description: siteDescription,
  applicationName: siteName,
  openGraph: {
    type: 'website',
    url: siteUrl,
    title: siteName,
    siteName,
    description: siteDescription,
    images: [
      { url: ogImage, width: 1200, height: 630, alt: 'Brittany Wright — Healing Through Chaos' }
    ],
    locale: 'en_US',
  },
  twitter: {
    card: 'summary_large_image',
    title: siteName,
    description: siteDescription,
    images: [ogImage],
  },
  icons: {
    icon: [{ url: '/headshot.jpg' }], // placeholder; replace with favicon later
  },
  robots: {
    index: true,
    follow: true
  },
  alternates: {
    canonical: siteUrl
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <SiteChrome>{children}</SiteChrome>
      </body>
    </html>
  );
}
