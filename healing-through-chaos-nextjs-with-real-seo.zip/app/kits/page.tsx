import React from 'react';

export default function KitsPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold text-white">Kits</h1>
      <ul className="list-disc pl-5 text-neutral-300 space-y-1">
        <li><a href="/docs/healing-through-chaos-workbook.docx" className="text-cyan-300 underline">Healing Through Chaos — 30‑Day Workbook (DOCX)</a></li>
        <li>Mother Sovereign Protection Kit — coming soon</li>
      </ul>
    </div>
  );
}
