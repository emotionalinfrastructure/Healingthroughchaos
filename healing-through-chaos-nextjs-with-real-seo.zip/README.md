# Healing Through Chaos (Next.js Repo with Real Files)

This repo is preloaded with Brittany Wright's real documents in `/public/docs/`.

## Quick Deploy (Mobile-Friendly)
1. Create a new repo on GitHub (via app or browser).
2. Upload this ZIP contents to that repo.
3. In the Vercel app, click "New Project" → Import GitHub repo.
4. Deploy. Vercel will host your site and serve docs from `/public/docs/...`.

## Files
All PDFs, DOCXs, and assets are inside `public/docs/` with clean filenames.

## SEO & Sharing
- Set your production URL so OG/Twitter images resolve correctly:
  ```bash
  vercel env add NEXT_PUBLIC_SITE_URL
  # e.g. https://healing-through-chaos.vercel.app or your custom domain
  ```
- `app/robots.ts` and `app/sitemap.ts` are auto-generated. Vercel will serve them at `/robots.txt` and `/sitemap.xml`.
- Open Graph image uses `/headshot.jpg` by default; swap for a designed OG image at `public/og.jpg` and update `ogImage` in `app/layout.tsx` if you prefer.
